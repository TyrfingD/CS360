package com.zybooks.travisgarlickinventoryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Login extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        //button that navigates to inventory screen
        Button loginButton = findViewById(R.id.buttonLogin);
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Login.this, Inventory.class));
            }
        });

        //eventual code to for checking login against a list
        //List<User> userList = userList.getInstance(getContext()).getUsername();
        //for (int i = 0; i < userList.size(); i++) {
            //if inputed username = any name on the list
            //and inputed password = password at same index array
            //then login and move to inventory screen

            //else{
                //add user to userList and password to passwords
            // }
        //}
    }
}
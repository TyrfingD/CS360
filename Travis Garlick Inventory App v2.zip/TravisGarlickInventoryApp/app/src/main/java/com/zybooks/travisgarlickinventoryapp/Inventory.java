package com.zybooks.travisgarlickinventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class Inventory extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        //button that navigates back to login screen
        Button logoutButton = findViewById(R.id.buttonLogout);
        logoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Inventory.this, Login.class));
            }
        });

        //add new item to inventory
        Button addItemButton = findViewById(R.id.addNew);
        addItemButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //set item name
                //add item to inventory list
            }
        });

        //onclick button_decrease
        Button decreaseButton = findViewById(R.id.buttonDecrease);
        decreaseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //get clicked inventory item's index
                //itemQuantity = quantity - 1
                //  if {itemQuantity = 0(send restock alert)}
            }
        });


        //onclick button_increase
        Button increaseButton = findViewById(R.id.buttonIncrease);
        increaseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //get clicked inventory item's index
                //itemQuantity = quantity + 1
            }
        });

    }
}

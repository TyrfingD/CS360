package com.zybooks.travisgarlickinventoryapp;

//new necessary import
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;
import android.content.Intent;
import android.app.IntentService;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

public class InventoryItem {

    //variable declarations
    private String mItemName;
    private int mItemQuantity;

    //empty constructor
    public InventoryItem(){}

    //constructor with variables
    public InventoryItem(String itemName, int itemQuantity){
        //assigns inputted user info
        mItemName = itemName;
        mItemQuantity = itemQuantity;
    }

    //getters
    public String getItemName(){
        return mItemName;
    }

    public int getItemQuantity() {return mItemQuantity; }

    //setters
    public void setName(String name) {
        this.mItemName = name;
    }

    public void setItemQuantity(Integer quantity) {
        this.mItemQuantity = quantity;
    }

    //code below creates the depleted item notifier
    private final String CHANNEL_ID_RESTOCK = "channel_restock";

    private void createRestockNotificationChannel() {
        if (Build.VERSION.SDK_INT < 26) return;

        int importance = NotificationManager.IMPORTANCE_LOW;
        NotificationChannel channel = new NotificationChannel(CHANNEL_ID_RESTOCK, mItemName, importance);
        //message content
        channel.setDescription("Alert: " + mItemName + "has reached zero quantity");
    }

}

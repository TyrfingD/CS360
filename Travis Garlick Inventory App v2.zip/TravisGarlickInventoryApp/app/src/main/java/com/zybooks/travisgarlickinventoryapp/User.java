package com.zybooks.travisgarlickinventoryapp;

//Java class for logins
public class User {

    //variable declarations
    private String mUserName;
    private String mPassword;

    //empty constructor
    public User(){}

    //constructor with variables
    public User(String userName, String password){
        //assigns inputed user info
        mUserName = userName;
        mPassword = password;
    }

    //getters
    public String getUserName(){
        return mUserName;
    }

    public String getPassword() {return mPassword; }

}
